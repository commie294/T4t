from django_project.telegrambot.manage import (
    main,
)

main()
