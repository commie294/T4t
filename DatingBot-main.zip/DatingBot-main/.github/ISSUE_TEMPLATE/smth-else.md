---
name: Smth else
about: Select this template if your issue is not related to other templates
title: ''
labels: 'Priority: Low, Status: Available'
assignees: ''

---

### What was wrong?
Briefly describe what went wrong or the issue that occurred.

### How can it be fixed?
Fill this section in if you know how this could or should be fixed.
