from . import (
    advert,
    customers,
    monitoring,
    settings,
)
